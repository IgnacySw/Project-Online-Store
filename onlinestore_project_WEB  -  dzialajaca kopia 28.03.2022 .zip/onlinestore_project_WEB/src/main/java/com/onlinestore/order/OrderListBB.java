package com.onlinestore.order;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.annotation.FacesConfig;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;

import onlinestore_project.dao.ProductDAO;
import onlinestore_project.dao.UserDAO;
import onlinestore_project.dao.ProductDAO;
import onlinestore_project.dao.OrderproductDAO;
import onlinestore_project.dao.MyorderDAO;
import onlinestore_project_ejbb.entities.Myorder;
import onlinestore_project_ejbb.entities.Orderproduct;
import onlinestore_project_ejbb.entities.Product;
import onlinestore_project_ejbb.entities.User;


@FacesConfig(version = FacesConfig.Version.JSF_2_3)
@Named
@RequestScoped
public class OrderListBB {
	private static final String PAGE_CART = "/pages/shop/cart?faces-redirect=true";
	private static final String PAGE_PERSON_EDIT = "table?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;
	private static final String PAGE_INDEX = "/public/index?faces-redirect=true";
	private String isbn;
	private String idOrder;
	private String login;
	private Product product;
	private Myorder order;
	private Orderproduct orderproduct;
	private User user;
	private List<Orderproduct> orderproducts;
	
	@Inject
	ExternalContext extcontext;
	
	@Inject
	FacesContext context;
	
	@Inject
	Flash flash;
	
	@EJB
	MyorderDAO orderDAO;
	@EJB
	OrderproductDAO orderproductDAO;
	@EJB
	ProductDAO productDAO;
	@EJB
	UserDAO	userDAO;
	
	public String getidOrder() {
		return idOrder;
	}
	
	public void setIdOrder(String idOrder) {
		this.idOrder = idOrder;
	}
	
	public List<Myorder> getFullList(){
		return orderDAO.getFullList();
	}
	
	public List<Myorder> getList(){
		List<Myorder> list = null;
		
		//1. Prepare search params
		Map<String,Object> searchParams = new HashMap<String, Object>();
		
		if (idOrder != null && idOrder.length() > 0){
			searchParams.put("idOrder", idOrder);
		}
		
		//2. Get list
		list = orderDAO.getList(searchParams);
		
		return list;
	}

	public String newOrder(Product u, User remoteClient){
			
					
	product = u;
	order = new Myorder();
	
		//long millis = System.currentTimeMillis();
		//java.sql.Date date = new java.sql.Date(millis);
	
	Date today = java.sql.Date.valueOf(java.time.LocalDate.now());
	Date receivedate = java.sql.Date.valueOf(java.time.LocalDate.now().plusWeeks(2));
		order.setDateOfOrder(today);
			System.out.println(receivedate);
		order.setDateOfReceive(receivedate);
		
	//order.setDateOfOrder(date); //DATE OF ORDER
		//long newmillis = millis + 1209600000;
		//java.sql.Date nowadata = new java.sql.Date(newmillis);
	
	
	//order.setDateOfReceive(nowadata); //DATE OF RECEIVE
		//order.setUser(remoteClient); //idUser
		//int a = remoteClient.getIdUser();
		//String login2 = remoteClient.getLogin();
		//User idusera = userDAO.findByIdUser(a);
		
		//User user = userDAO.find(userDAO.getUserID(login2));
	//System.out.println(user.getName());
		User user = userDAO.findBySurname(remoteClient.getSurname());
			System.out.println(user);
		order.setUser(user);
	//
		//order.setOrderbooks(orderbooks);
		/*
		 * SimpleDateFormat format = new SimpleDateFormat("yyyy-M-dd"); Calendar
		 * calendar = Calendar.getInstance(); Date data1; try { data1 =
		 * format.parse(Calendar.getInstance().toString());
		 * 
		 * order.setDateOfOrder(data1); } catch (ParseException e1) { // TODO
		 * Auto-generated catch block e1.printStackTrace(); }
		 */
			
		
		
			
					//String sDate1 = calendar.toString();
					//DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy/MM/dd");
					//LocalDate localDate = LocalDate.parse(sDate1, format);
					//java.sql.Date dob   = java.sql.Date.valueOf(localDate);
			
		
		
		
					/*
					 * calendar.add(Calendar.DATE, noOfDays); try { Date data2 =
					 * format.parse(calendar.getInstance().toString()); } catch (ParseException e) {
					 * // TODO Auto-generated catch block e.printStackTrace(); }
					 */
			//String sDate2 = calendar.toString();
			//LocalDate DateOfRec = LocalDate.parse(sDate2, format);
			//java.sql.Date dob2 = java.sql.Date.valueOf(DateOfRec);
			
			//String nowy = calendar.toString();
			//Date newDate = new java.sql.Date(new wwSimpleDateFormat("yyyy-MM-dd").parse(nowy).getTime());
			//calendar.add(Calendar.DAY_OF_YEAR, noOfDays);
		//order.setDateOfReceive(calendar.getTime());
		//order.setOrderbooks(orderbooks);
		
		
		
		
		
		
		 //.setOrder niby id ale chyba powinnen byc sam order
		orderproduct = new Orderproduct();
		//orderbook = b;
		orderproduct.setProduct(product); //idBook
		
		
		orderproduct.setMyorder(order); //idOrder
		orderproduct.setPrice(product.getPrice()); //price
		//order.setOrderbooks(orderbooks);
		///orderbook.setIdOrderBook(0);             //??
		//Order order = new Order();
		//Orderbook orderbook = new Orderbook();
		//pobierz id usera
		//order.getUser().getIdUser();
		
		//pobierz
		
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash	
		//flash.put("order", order);
		//flash.put("orderbook", orderbook);
		try {
			// always a new record
			orderDAO.create(order);
			orderproductDAO.create(orderproduct);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu zamówienia", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_INDEX;
	
		
		
	}

	public String editOrder(Myorder order){
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash 
		flash.put("order", order);
		
		return PAGE_PERSON_EDIT;
	}

	public String deleteOrder(Myorder order){
		orderDAO.remove(order);
		return PAGE_STAY_AT_THE_SAME;
	}
	
	// GETTER && SETTER
	
	public Product getProduct() {
		return product;
	}
	
	public void setProduct(Product product) {
		this.product = product;
	}
	
	public Myorder getOrder() {
		return order;
	}
	
	public void setOrder(Myorder order) {
		this.order = order;
	}
	
	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	public Orderproduct getOrderproduct() {
		return orderproduct;
	}
	
	public void setOrderproduct(Orderproduct orderproduct) {
		this.orderproduct = orderproduct;
	}
	
	
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getIsbn() {
		return isbn;
	}
	
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	public List<Orderproduct> getOrderproducts() {
		return this.orderproducts;
	}

	public void setOrderproducts(List<Orderproduct> orderproducts) {
		this.orderproducts = orderproducts;
	}
}
