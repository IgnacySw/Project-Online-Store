package com.onlinestore.orderproduct;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.annotation.FacesConfig;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;

import onlinestore_project.dao.OrderproductDAO;
import onlinestore_project_ejbb.entities.Myorder;
import onlinestore_project_ejbb.entities.Orderproduct;
import onlinestore_project.dao.ProductDAO;
import onlinestore_project_ejbb.entities.Product;

@FacesConfig(version = FacesConfig.Version.JSF_2_3)
@Named
@RequestScoped
public class OrderBookListBB {

	private static final String PAGE_PERSON_EDIT = "table?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;
	private static final String PAGE_BUY_CONFIRM = "cart?faces-redirect=true";
	
	private int idOrderProduct;
	
	@Inject
	ExternalContext extcontext;
	
	@Inject
	Flash flash;
	
	@EJB
	OrderproductDAO orderproductDAO;
	
	@EJB
	ProductDAO productDAO;
	
	public int getIdOrderProduct() {
		return idOrderProduct;
	}
	
	public void setIdOrderProduct(int idOrderProduct) {
		this.idOrderProduct = idOrderProduct;
	}
	
	public List<Orderproduct> getList(){
		List<Orderproduct> list = null;
		
		//1. Prepare search params
		Map<String,Object> searchParams = new HashMap<String, Object>();
		
		if (Integer.toString(idOrderProduct) != null && Integer.toString(idOrderProduct).length() > 0){
			searchParams.put("idOrderProduct", idOrderProduct);
		}
		
		//2. Get list
		list = orderproductDAO.getList(searchParams);
		
		return list;
	}
	
	public String newOrderProduct(){
		Orderproduct orderproduct = new Orderproduct();
		
		orderproduct.getProduct().addOrderproduct(orderproduct);
		//pobierz cene produktu
		
		//pobierz id produktu
		
		//pobierz id order
		
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash	
		flash.put("orderproduct", orderproduct);
		
		return PAGE_BUY_CONFIRM;
	}
	
	public String editOrderProduct(Orderproduct orderproduct){
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash 
		flash.put("orderproduct", orderproduct);
		
		return PAGE_PERSON_EDIT;
	}

	public String deleteOrderProduct(Orderproduct orderproduct){
	
		orderproductDAO.remove(orderproduct);
		return PAGE_STAY_AT_THE_SAME;
	}
	
	
}
