package com.onlinestore.product;

import java.io.IOException;
import java.io.Serializable;

import javax.ejb.EJB;
import javax.faces.annotation.FacesConfig;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import onlinestore_project.dao.ProductDAO;
import onlinestore_project.dao.UserDAO;
import onlinestore_project_ejbb.entities.Product;
import onlinestore_project_ejbb.entities.User;
@FacesConfig(version = FacesConfig.Version.JSF_2_3)
@Named
@ViewScoped
public class BookEditBB implements Serializable {

	private static final long serialVersionUID = 1L;

	
	private static final String PAGE_STAY_AT_THE_SAME = null;
	private static final String PAGE_SHOP = "/pages/shop/table?faces-redirect=true";

	private Product product = new Product();
	private Product loaded = null;

	@EJB
	ProductDAO productDAO;

	@Inject
	FacesContext context;

	@Inject
	Flash flash;

	public Product getProduct() {
		return product;
	}

	public void onLoad() throws IOException {
		// 1. load person passed through session
		// HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		// loaded = (Person) session.getAttribute("person");

		// 2. load person passed through flash
		loaded = (Product) flash.get("product");

		// cleaning: attribute received => delete it from session
		if (loaded != null) {
			product = loaded;
			// session.removeAttribute("person");
		} else {
			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
			// if (!context.isPostback()) { //possible redirect
			// context.getExternalContext().redirect("personList.xhtml");
			// context.responseComplete();
			// }
		}

	}

	public String saveData() {
		// no Person object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}

		try {
			if (Integer.valueOf(product.getIdProduct()) == null) {
				// new record
				productDAO.create(product);
			} else {
				// existing record
				productDAO.merge(product);
			}
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_SHOP;
	}
}
