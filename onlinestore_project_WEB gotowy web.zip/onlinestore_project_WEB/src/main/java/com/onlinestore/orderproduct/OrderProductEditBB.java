package com.onlinestore.orderproduct;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Serializable;

import javax.ejb.EJB;
import javax.faces.annotation.FacesConfig;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import org.primefaces.PrimeFaces;

import onlinestore_project.dao.OrderproductDAO;
import onlinestore_project_ejbb.entities.Orderproduct;
import onlinestore_project_ejbb.entities.Role;

@FacesConfig(version = FacesConfig.Version.JSF_2_3)
@Named
@ViewScoped
public class OrderProductEditBB implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private static final String PAGE_PERSON_LIST = "/pages/shop/table?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;
	
	private Orderproduct orderproduct = new Orderproduct();
	private Orderproduct loaded = null;
	
	@EJB
	OrderproductDAO orderproductDAO;
	
	@Inject
	FacesContext context;
	
	@Inject
	Flash flash;
	
	public Orderproduct getOrderproduct() {
		return orderproduct;
	}
	
	public void onLoad() throws IOException {
		// 1. load person passed through session
		// HttpSession session = (HttpSession)
		// context.getExternalContext().getSession(true);
		// loaded = (Person) session.getAttribute("person");

		// 2. load person passed through flash
		loaded = (Orderproduct) flash.get("orderproduct");

		// cleaning: attribute received => delete it from session
		if (loaded != null) {
			orderproduct = loaded;
			// session.removeAttribute("person");
		} else {
			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
			// if (!context.isPostback()) { //possible redirect
			// context.getExternalContext().redirect("personList.xhtml");
			// context.responseComplete();
			// }
		}

	}
	
	public String saveData() {

		// no Person object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}
		//Role role = new Role();
		//role.setIdRole(2);
		
		//Role role = roleDAO.findByName("User");
		//user.setRole(role);

		try {
			// always a new record
			orderproductDAO.create(orderproduct);
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_PERSON_LIST;
	}
}
